package employee;

public class PartTimeEmp {
	// declare fields here
	
	public PartTimeEmp() {
// implement here
	}

	public PartTimeEmp(int id, String name, DepartmentEnum department, int hours) {
// implement here
	}
	
	public void print() {
// implement here
	}
}
