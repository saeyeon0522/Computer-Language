package employee;

public enum PositionEnum {
// implement here
}
